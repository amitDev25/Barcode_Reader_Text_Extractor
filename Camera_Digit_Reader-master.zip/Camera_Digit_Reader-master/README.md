# Camera_Digit_Reader
ESP32-CAM and Python codes to read digits

Demo : https://youtu.be/4woGh91g51E
